____________________________________________________________________________________________________
  _____   _   _   __     ____     _   _   __     ______   _   _   ____     _____
  /  )  /  /    / |    /  )  /  /|    / |      /    |  /    /  )  /  ‘
—-/——/——/___ /——-/__|——/___ /——/| /-|——/__|————/————|—-/——-/____/——/__——
  /  /  /  /    /  |  /  |  / |/  |  /  |    /      |  /    /      /
_/____/____/____/_____/____|__/_____|___/__/___|__/____|______/__________|_/_____/_________/____ ___
                                                  /
                                              (_ /    DHARMA TYPE FREE FONTs

EULA ( the End User License Agreement )

This document is a legal agreement between you the end user, and Dharma Type.
By using or installing Dharma Type font(s), you agree to be bound by the terms of this Agreement.

1. You may use this font for both commercial and non-commercial works at no charge.
2. You may use this font to create images on the website or printed matter on papre, logomark…..up to you.
3. You may not sell this font without permission.
4. You may not redistribute this font without permission.
5. You may not modify, adapt, translate, reverse engineer, decompile, disassemble, or create derivative works based on this font.
6. This font are Copyrighted by Ryoichi Tsunekawa. All rights reserved. You may not claim copyrgiht rights for this font.
7. DISCLAIMER
This font is provided to you free of charge.
Dharma Type give no warranty in relation to this font, and you use this at your own risk.
Dharma Type will not be liable for any damage to your system, any loss or corruption of any data or software,
or any other loss or damage that you may suffer as a result of downloading or using this font, whether it results from our negligence or in any other way.

Here is a list of things you could do, Only if you want to:
* Link http://dharmatype.com/ or credit “Dharma Type”
* Tell me what did you use this font for.

FAQ

Q_ Can I use this for a commercial product?
A_ Yes, You can!

Q_ Can I use this on a web page via css @font-face?
A_ Yes, You can!

Q_ Can I donate $ to you?
A_ Yes, You can! ( Paypal: info@flat-it.com )

Contact_______________________________

info@dharmatype.com